### Decision-Tree
This repository has Jupyter notebook of decision tree which uses gini index.
If any doubts you have wathc this video this will help to clear it :https://www.youtube.com/watch?v=q90UDEgYqeI&t=3543s&ab_channel=StatQuestwithJoshStarmer
